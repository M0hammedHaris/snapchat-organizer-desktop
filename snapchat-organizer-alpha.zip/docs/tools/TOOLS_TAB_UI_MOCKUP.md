# Tools Tab - Visual UI Mockup

## Main Window with Tools Tab Selected

```
╔═══════════════════════════════════════════════════════════════════════════╗
║  Snapchat Organizer Desktop v1.0.0-alpha                             ☐ ✕ ║
╠═══════════════════════════════════════════════════════════════════════════╣
║  File    Help                                                             ║
╠═══════════════════════════════════════════════════════════════════════════╣
║  ┌─────────────────┬──────────────────────┬─────────────────────────────┐║
║  │ 📥 Download     │ 📁 Organize Chat    │ 🔧 Tools                    │║
║  │   Memories      │    Media             │    [ACTIVE]                 │║
║  └─────────────────┴──────────────────────┴─────────────────────────────┘║
║                                                                           ║
║  ┌─────────────────────────────────────────────────────────────────────┐ ║
║  │  🔧 Utility Tools                                                   │ ║
║  │                                                                     │ ║
║  │  Select a folder and choose a tool to perform various operations   │ ║
║  │  on your media files. Each tool provides specific functionality    │ ║
║  │  for managing and optimizing your Snapchat media collection.       │ ║
║  └─────────────────────────────────────────────────────────────────────┘ ║
║                                                                           ║
║  ┌─────────────────────────────────────────────────────────────────────┐ ║
║  │  📁 Folder Selection                                                │ ║
║  │  ┌───────────────────────────────────────────────────────────────┐ │ ║
║  │  │ Target Folder:  /Users/john/Downloads/snapchat  │  Browse...  │ │ ║
║  │  └───────────────────────────────────────────────────────────────┘ │ ║
║  └─────────────────────────────────────────────────────────────────────┘ ║
║                                                                           ║
║  ┌─────────────────────────────────────────────────────────────────────┐ ║
║  │  🛠️ Available Tools                                                 │ ║
║  │  ┌─────────────────────────────────┬────────────────────────────┐  │ ║
║  │  │  ✅ Verify Files                │  🔄 Remove Duplicates      │  │ ║
║  │  │                                  │                            │  │ ║
║  │  │  Check file integrity and        │  Detect and remove         │  │ ║
║  │  │  detect corrupted media          │  duplicate files using     │  │ ║
║  │  │                                  │  hash comparison           │  │ ║
║  │  ├─────────────────────────────────┼────────────────────────────┤  │ ║
║  │  │  🎨 Apply Overlays              │  🌍 Convert Timezone      │  │ ║
║  │  │                                  │                            │  │ ║
║  │  │  Composite Snapchat overlays     │  Convert timestamps using  │  │ ║
║  │  │  onto media files                │  GPS-based timezone        │  │ ║
║  │  │                                  │  detection                 │  │ ║
║  │  ├─────────────────────────────────┼────────────────────────────┤  │ ║
║  │  │  📅 Organize by Year            │  ⏰ Fix Timestamps         │  │ ║
║  │  │                                  │                            │  │ ║
║  │  │  Reorganize files into year-     │  Correct file timestamps   │  │ ║
║  │  │  based folder structure          │  from EXIF metadata        │  │ ║
║  │  │                                  │                            │  │ ║
║  │  └─────────────────────────────────┴────────────────────────────┘  │ ║
║  └─────────────────────────────────────────────────────────────────────┘ ║
║                                                                           ║
║  ┌─────────────────────────────────────────────────────────────────────┐ ║
║  │  ████████████████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░  67%      │ ║
║  └─────────────────────────────────────────────────────────────────────┘ ║
║  Processing file 200 of 300                                  ETA: 1m 23s ║
║  Current: Calculating hash for IMG_2024_05_15_142233.jpg                 ║
║                                                                [Cancel]   ║
║                                                                           ║
║  ┌─────────────────────────────────────────────────────────────────────┐ ║
║  │  📊 Results & Statistics                                            │ ║
║  │  ┌───────────────────────────────────────────────────────────────┐ │ ║
║  │  │  DUPLICATE REMOVAL RESULTS                                    │ │ ║
║  │  │  ==================================================            │ │ ║
║  │  │                                                                │ │ ║
║  │  │  Total Files Scanned: 300                                     │ │ ║
║  │  │  Unique Files: 250                                            │ │ ║
║  │  │  Duplicate Files Found: 50                                    │ │ ║
║  │  │  Space Saved: 245.67 MB                                       │ │ ║
║  │  │                                                                │ │ ║
║  │  │  Duplicates moved to: /Users/john/Downloads/snapchat/...     │ │ ║
║  │  │                                                                │ │ ║
║  │  │  Status: ✅ 50 duplicates removed                             │ │ ║
║  │  │                                                                │ │ ║
║  │  └───────────────────────────────────────────────────────────────┘ │ ║
║  └─────────────────────────────────────────────────────────────────────┘ ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
```

## Tool Button Interaction States

### Idle State (Before Selection)
```
┌─────────────────────────────────┐
│  ✅ Verify Files                │
│                                  │
│  Check file integrity and        │
│  detect corrupted media          │
│                                  │
└─────────────────────────────────┘
```

### Hover State
```
┌─────────────────────────────────┐  ← Blue border
│  ✅ Verify Files                │  ← Light blue background
│                                  │
│  Check file integrity and        │
│  detect corrupted media          │
│                                  │
└─────────────────────────────────┘
```

### Disabled State (While Another Tool is Running)
```
┌─────────────────────────────────┐
│  ✅ Verify Files                │  ← Grayed out
│                                  │
│  Check file integrity and        │
│  detect corrupted media          │
│                                  │
└─────────────────────────────────┘
```

## Confirmation Dialog

```
╔═══════════════════════════════════════════════════╗
║  Run Remove Duplicates                        ✕  ║
╠═══════════════════════════════════════════════════╣
║                                                   ║
║  Remove duplicates in:                            ║
║  /Users/john/Downloads/snapchat                   ║
║                                                   ║
║  This will detect duplicate files using hash      ║
║  comparison and move duplicates to a              ║
║  'duplicates' subfolder.                          ║
║                                                   ║
║  Do you want to continue?                         ║
║                                                   ║
║                          ┌─────────┐  ┌─────────┐║
║                          │   No    │  │  Yes    │║
║                          └─────────┘  └─────────┘║
╚═══════════════════════════════════════════════════╝
```

## Completion Dialog

```
╔═══════════════════════════════════════════════════╗
║  Tool Completed                               ✕  ║
╠═══════════════════════════════════════════════════╣
║                                                   ║
║  ℹ️  Remove Duplicates completed successfully!   ║
║                                                   ║
║  Check the Results & Statistics section for       ║
║  details.                                         ║
║                                                   ║
║                                     ┌───────────┐ ║
║                                     │    OK     │ ║
║                                     └───────────┘ ║
╚═══════════════════════════════════════════════════╝
```

## Color Scheme

- **Primary Color**: #0078d4 (Blue) - Used for hover states and active elements
- **Background**: #ffffff (White) - Main background
- **Tool Buttons**: #ffffff with #ddd border
- **Tool Buttons Hover**: #f0f8ff (Light blue) with #0078d4 border
- **Disabled State**: #f5f5f5 background, #999 text
- **Progress Bar**: Blue gradient
- **Statistics Box**: White with light gray border
- **Text**: #333 (Dark gray) for main text, #666 for descriptions

## Responsive Behavior

### Window Resize
- Minimum width: 900px
- Minimum height: 700px
- Tool buttons maintain aspect ratio
- Statistics box expands vertically
- Scroll area activates if content exceeds window height

### Long File Paths
```
Target Folder: /Users/john/Documents/Snapchat/Memo...  [Browse...]
                ↑ Truncated with ellipsis
```

### Many Results
```
┌───────────────────────────────────────────────────────────────┐
│  YEAR ORGANIZATION RESULTS                                    │
│  ==================================================            │
│  ... (scrollable content) ...                                 │
│  ▲ Scroll bar appears on right                                │
│  █                                                             │
│  ░                                                             │
│  ░                                                             │
│  ▼                                                             │
└───────────────────────────────────────────────────────────────┘
```

## Keyboard Shortcuts

- **Ctrl+O**: Browse folder
- **Ctrl+1**: Activate Verify Files tool
- **Ctrl+2**: Activate Remove Duplicates tool
- **Ctrl+3**: Activate Apply Overlays tool
- **Ctrl+4**: Activate Convert Timezone tool
- **Ctrl+5**: Activate Organize by Year tool
- **Ctrl+6**: Activate Fix Timestamps tool
- **Esc**: Cancel running operation

## Accessibility Features

1. **High Contrast Mode**: All colors meet WCAG AA standards
2. **Keyboard Navigation**: All tools accessible via Tab key
3. **Screen Reader Support**: All buttons have descriptive labels
4. **Large Buttons**: 100px minimum height for easy clicking
5. **Clear Labels**: Icons + text descriptions for clarity

## Animation/Transitions

1. **Progress Bar**: Smooth animation (100ms ease-out)
2. **Button Hover**: Fade background color (200ms ease-in-out)
3. **Statistics Appear**: Fade in (300ms ease-in)
4. **Tool Selection**: Instant feedback (no delay)

## Error States

### Invalid Folder
```
╔═══════════════════════════════════════════════════╗
║  Invalid Folder                               ✕  ║
╠═══════════════════════════════════════════════════╣
║                                                   ║
║  ⚠️  The selected folder does not exist:          ║
║                                                   ║
║  /Users/john/Downloads/old_snapchat               ║
║                                                   ║
║                                     ┌───────────┐ ║
║                                     │    OK     │ ║
║                                     └───────────┘ ║
╚═══════════════════════════════════════════════════╝
```

### Tool Failure
```
╔═══════════════════════════════════════════════════╗
║  Tool Failed                                  ✕  ║
╠═══════════════════════════════════════════════════╣
║                                                   ║
║  ❌  The tool operation failed:                   ║
║                                                   ║
║  Permission denied: Cannot write to folder        ║
║                                                   ║
║                                     ┌───────────┐ ║
║                                     │    OK     │ ║
║                                     └───────────┘ ║
╚═══════════════════════════════════════════════════╝
```

## Dark Mode Support (Future)

All colors have dark mode alternatives:
- Background: #1e1e1e
- Tool buttons: #2d2d2d with #404040 border
- Text: #e0e0e0
- Hover: #3d3d3d with #0078d4 border
- Progress bar: Blue gradient (same hue, adjusted brightness)
