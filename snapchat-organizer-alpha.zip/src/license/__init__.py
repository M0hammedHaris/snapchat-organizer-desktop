"""Snapchat Organizer Desktop - License management package."""
