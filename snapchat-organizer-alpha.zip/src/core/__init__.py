"""Snapchat Organizer Desktop - Core business logic package."""
